./gradlew :kotlinpleaseanimate:clean
./gradlew :kotlinpleaseanimate:assembleDebug
./gradlew :kotlinpleaseanimate:install
./gradlew :kotlinpleaseanimate:bintrayUpload