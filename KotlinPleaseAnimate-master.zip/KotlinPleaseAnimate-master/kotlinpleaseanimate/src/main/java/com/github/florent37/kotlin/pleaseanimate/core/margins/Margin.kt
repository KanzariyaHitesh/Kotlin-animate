package com.github.florent37.kotlin.pleaseanimate.core.margins

enum class Margin {
    TOP,
    BOTTOM,
    LEFT,
    RIGHT
}