package com.github.florent37.kotlin.pleaseanimate.core.paddings

enum class Padding {
    TOP,
    BOTTOM,
    LEFT,
    RIGHT
}